import React from 'react'

const Footer =()=>{
    
    return(
        <>
        <h4 style={{textAlign:'center', paddingTop:'50px',}}>&copy; E-Cube Solutions</h4>
        <h6 style={{textAlign:'center', marginBottom:'3px'}}>Desgined & Developed</h6>
        <h6 style={{textAlign:'center', }}>By</h6>
        <h6 style={{textAlign:'center', fontStyle:'italic', paddingBottom:'50px'}}>Rithik</h6>
        </>
    )
}
export default Footer;